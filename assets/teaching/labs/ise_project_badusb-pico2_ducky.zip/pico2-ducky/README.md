<h1 align="center">pico2-ducky - Forked from [pico-ducky](https://github.com/dbisu/pico-ducky) repository</h1>

<div align="center">
  <strong>Make a cheap but powerful USB Rubber Ducky with a Raspberry Pi Pico</strong>
</div>


## Quick Start Guide
Install and have your USB Rubber Ducky working in less than 5 minutes. You can simply run the `installer.sh` script to set up the Rubber Ducky. **Do not plug the device before running the script: simply run the script and follow instructions.**

If the script doesn't work as intended for some reasons, follow these steps to manually setup the device.

1. Download all dependencies.
  * [CircuitPython v9.2.5](https://downloads.circuitpython.org/bin/raspberry_pi_pico2/fr/adafruit-circuitpython-raspberry_pi_pico2-fr-9.2.5.uf2)
  * [CircuitPython bundle v9.x](https://github.com/adafruit/Adafruit_CircuitPython_Bundle/releases/download/20250319/adafruit-circuitpython-bundle-9.x-mpy-20250319.zip)
  * [flash_nuke.uf2 ](https://datasheets.raspberrypi.com/soft/flash_nuke.uf2)
  * [Additionnal keyboards layouts ](https://github.com/Neradoc/Circuitpython_Keyboard_Layouts/releases/download/20231122/circuitpython-keyboard-layouts-py-20231122.zip)

2. Plug the device into a USB port **while holding the boot button**. It will show up as a removable media device named RP2350.

3. Install CircutlPython on the Pico:
Copy the adafruit-circuitpython-raspberry_pi_pico2-en_US-9.2.5.uf2 file to the root of the Pico 2 (RP2350). The device will reboot and after a second or so, it will reconnect as CIRCUITPY.

4. Install pico-ducky and friends:
  * Unzip adafruit-circuitpython-bundle-9.x-mpy-20250319.zip 
  * From the extracted folder, copy `lib/adafruit_hid`, `lib/adafruit_debouncer.mpy`, `lib/adafruit_ticks.mpy` and `lib/asyncio` into a folder `/lib` at the root of the device.
  * Copy the python files provided by this repository (`boot.py`, `duckyinpython.py`, `code.py`) to the root of the device.

5. Install additional keyboard layouts to get azerty keaybord support.
  * Unzip circuitpython-keyboard-layouts-py-20231122.zip
  * Copy `lib/keyboard_layout_win_fr.py`, `lib/keycode_mac_fr.py`, `lib/keyboard_layout_mac_fr.py` and `lib/keycode_win_fr.py` to the `/lib/` folder on the device.

Your device is now a Rubber Ducky. You can follow the next steps to deploy your scripts:

1. Follow the instructions in README.md to enter setup mode

2. Copy your payload as `/payloads/payload.dd` (beware, the name and folder are important) on the CIRCUITPY device.

3. Unplug the device from the USB port and remove the setup jumper.

Enjoy your Pico-Ducky.

## Setup mode

To edit the payload, enter setup mode by connecting the pin 1 (`GP0`) to pin 3 (`GND`), this will stop the pico-ducky from injecting the payload in your own machine.
The easiest way to do so is by using a jumper wire between those pins as seen bellow.

![Setup mode with a jumper](images/setup-mode.png)

## USB enable/disable mode

If you need the pico-ducky to not show up as a USB mass storage device for stealth, follow these instructions.  
- Enter setup mode.    
- Copy your payload script to the pico-ducky, in the `/payloads/` directory.  
- Disconnect the pico from your host PC.
- Connect a jumper wire between pin 18 (`GND`) and pin 20 (`GPIO15`).  
This will prevent the pico-ducky from showing up as a USB drive when plugged into the target computer.  
- Remove the jumper and reconnect to your PC to reprogram.  

Pico: The default mode is USB mass storage enabled.   
Pico W: The default mode is USB mass storage **disabled**  

![USB enable/disable mode](images/usb-boot-mode.png)

## Multiple payloads

Multiple payloads can be stored on the Pico and Pico W.  
To select a payload, ground one of these pins:
- GP4 - payload.dd
- GP5 - payload2.dd
- GP10 - payload3.dd
- GP11 - payload4.dd

## Changing Keyboard Layouts

This fork is adapted to set a french keyboard by default. It is automatically managed by the installation script, but in case of manual installation, you should get the apporpriate files as follows:

Copied from [Neradoc/Circuitpython_Keyboard_Layouts](https://github.com/Neradoc/Circuitpython_Keyboard_Layouts/blob/main/PICODUCKY.md)  

#### How to use one of these layouts with the pico-ducky repository.

**Go to the [latest release page](https://github.com/Neradoc/Circuitpython_Keyboard_Layouts/releases/latest), look if your language is in the list.**

#### If your language/layout is in the bundle

Download the `py` zip, named `circuitpython-keyboard-layouts-py-XXXXXXXX.zip`

**NOTE: You can use the mpy version targetting the version of Circuitpython that is on the device, but on Raspberry Pi Pico you don't need it - they only reduce file size and memory use on load, which the pico has plenty of.**

#### If your language/layout is not in the bundle

Try the online generator, it should get you a zip file with the bundles for yout language

https://www.neradoc.me/layouts/

#### Now you have a zip file

#### Find your language/layout in the lib directory

For a language `LANG`, copy the following files from the zip's `lib` folder to the `lib` directory of the board.  
**DO NOT** modify the adafruit_hid directory. Your files go directly in `lib`.  
**DO NOT** change the names or extensions of the files. Just pick the right ones.  
Replace `LANG` with the letters for your language of choice.

- `keyboard_layout_win_LANG.py`
- `keycode_win_LANG.py`

Don't forget to get [the adafruit_hid library](https://github.com/adafruit/Adafruit_CircuitPython_HID/releases/latest).

This is what it should look like **if your language is French for example**.

![CIRCUITPY drive screenshot](https://github.com/Neradoc/Circuitpython_Keyboard_Layouts/raw/main/docs/drive_pico_ducky.png)

#### Modify the pico-ducky code to use your language file:

At the start of the file comment out these lines:

```py
from adafruit_hid.keyboard_layout_us import KeyboardLayoutUS as KeyboardLayout
from adafruit_hid.keycode import Keycode
```

Uncomment these lines:  
*Replace `LANG` with the letters for your language of choice. The name must match the file (without the py or mpy extension).*
```py
from keyboard_layout_win_LANG import KeyboardLayout
from keycode_win_LANG import Keycode
```

##### Example:  Set to German Keyboard (WIN_DE)

```py
from keyboard_layout_win_de import KeyboardLayout
from keycode_win_de import Keycode
```

Copy the files keyboard_layout_win_de.mpy and keycode_win_de.mpy to the /lib folder on the Pico board
```
adafruit_hid/
keyboard_layout_win_de.mpy
keycode_win_de.mpy
```



## Useful links and resources

### How to recover your Pico if it becomes corrupted or doesn't boot.

[Reset Instructions](RESET.md)

### Installation Tool

[raspberrydeveloper](https://github.com/raspberrydeveloper) Created a tool to convert a blank RPi Pico to a ducky.  
You can find the tool [here](https://github.com/raspberrydeveloper/pyducky)

### Docs

[CircuitPython](https://circuitpython.readthedocs.io/en/6.3.x/README.html)

[CircuitPython HID](https://learn.adafruit.com/circuitpython-essentials/circuitpython-hid-keyboard-and-mouse)

[Ducky Script](https://github.com/hak5darren/USB-Rubber-Ducky/wiki/Duckyscript)

### Video tutorials

[pico-ducky tutorial by **NetworkChuck**](https://www.youtube.com/watch?v=e_f9p-_JWZw)

[USB Rubber Ducky playlist by **Hak5**](https://www.youtube.com/playlist?list=PLW5y1tjAOzI0YaJslcjcI4zKI366tMBYk)

[CircuitPython tutorial on the Raspberry Pi Pico by **DroneBot Workshop**](https://www.youtube.com/watch?v=07vG-_CcDG0)


## Related Projects

[Defcon31-ducky](https://github.com/iot-pwn/defcon31-ducky)  
There are still a few of these available to purchase, US only.
