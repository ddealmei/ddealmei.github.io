#!/usr/bin/env bash

# Script for installing pico-ducky on a Raspberry Pi Pico 2

CIRCUITPYTHON_BUNDLE_VERSION="9.x"
CIRCUITPYTHON_BUNDLE_FILE="adafruit-circuitpython-bundle-9.x-mpy-20250319.zip"
CIRCUITPYTHON_VERSION="9.2.5"
CIRCUITPYTHON_LANG="fr"
CIRCUITPYTHON_FILE="adafruit-circuitpython-raspberry_pi_pico2-${CIRCUITPYTHON_LANG}-${CIRCUITPYTHON_VERSION}.uf2"

PI_NAME="RP2350" # "RPI-RP2" for pico 1

waitForFile() {
    local DEV_NAME=$1
    local MOUNT_POINT

    echo -e "\tWaiting for $DEV_NAME mount..." >&2
    while true; do
        # Recherche dynamique du point de montage
        MOUNT_POINT=$(find /media /run/media -maxdepth 2 -type d -name "$DEV_NAME" 2>/dev/null | head -n 1)

        if [[ -n "$MOUNT_POINT" ]]; then
            echo -e "\tDevice detected at $MOUNT_POINT" >&2
            break
        else
            echo -e "\tNo device detected. Make sure it is mounted (open the folder)." >&2
            read -p "Press [Enter] to retry or provide the correct path: " USER_INPUT >&2
            if [[ -n "$USER_INPUT" ]]; then
                MOUNT_POINT="$USER_INPUT"
                break
            fi
        fi
        sleep 2
    done

    # Seul le point de montage est envoyé sur stdout
    echo "$MOUNT_POINT"
}

set -e
SCRIPTDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null && pwd )"
CACHEDIR=/tmp/pico-ducky-cache
mkdir -p $CACHEDIR
cd $CACHEDIR
echo -e "\tDownloading CircuitPython $CIRCUITPYTHON_VERSION"
set +e;
ls ${CIRCUITPYTHON_FILE} &> /dev/null
CACHED=$?
set -e
if [ "$CACHED" -eq 0 ]
then
    echo -e "\tUsing cached ${CIRCUITPYTHON_FILE}"
else
    wget -q -nv  https://downloads.circuitpython.org/bin/raspberry_pi_pico2/${CIRCUITPYTHON_LANG}/${CIRCUITPYTHON_FILE}
fi

echo -e "\tDownloading CircuitPython bundle $CIRCUITPYTHON_BUNDLE_VERSION"
cd $CACHEDIR
set +e
ls $CIRCUITPYTHON_BUNDLE_FILE &> /dev/null
CACHED=$?
set -e
if [ "$CACHED" -eq 0 ]
then
    echo -e "\tUsing cached $CIRCUITPYTHON_BUNDLE_FILE"
else
    wget -q -nv https://github.com/adafruit/Adafruit_CircuitPython_Bundle/releases/download/20250319/$CIRCUITPYTHON_BUNDLE_FILE
fi

echo -e "\tDownloading flash_nuke.uf2"
set +e
ls flash_nuke.uf2 &> /dev/null
CACHED=$?
set -e
if [ "$CACHED" -eq 0 ]
then
    echo -e "\tUsing cached flash_nuke.uf2"
else
    wget -nv https://datasheets.raspberrypi.com/soft/flash_nuke.uf2
fi

echo -e "\tDownloading additional keyboard layouts"
cd $CACHEDIR
set +e
ls circuitpython-keyboard-layouts-py-20231122.zip &> /dev/null
CACHED=$?
set -e
if [ "$CACHED" -eq 0 ]
then
    echo -e "\tUsing cached circuitpython-keyboard-layouts-py-20231122.zip"
else
    wget -nv https://github.com/Neradoc/Circuitpython_Keyboard_Layouts/releases/download/20231122/circuitpython-keyboard-layouts-py-20231122.zip
fi
unzip -q -o "*.zip"

echo -e "
################################################################################
#                                  Important                                   #
################################################################################
Hold the button on the Pico 2 and plug it in so it shows up as mass storage device "${PI_NAME}"\n"

MOUNT_PATH=$(waitForFile "${PI_NAME}")
echo -e "Cleanning the card with flash_nuke... "
cp $CACHEDIR/flash_nuke.uf2 "${MOUNT_PATH}/"
echo -e "\tDone!\n"

echo -e "Waiting for the Pico to reboot..."
sleep 3

MOUNT_PATH=$(waitForFile "${PI_NAME}")
echo -en "Installing CircuitPython image... "
cp $CACHEDIR/$CIRCUITPYTHON_FILE "${MOUNT_PATH}/"
echo "\n\tDone!"

echo -e "Waiting for the Pico 2 to reboot again..."
sleep 3

MOUNT_PATH=$(waitForFile "CIRCUITPY")
echo -e "\nInstalling pico-ducky and friends..."
cd "${MOUNT_PATH}/"
CPBUNDLEDIR=$CACHEDIR/${CIRCUITPYTHON_BUNDLE_FILE/.zip}/
cp -r $CPBUNDLEDIR/lib/adafruit_hid lib/
cp -r $CPBUNDLEDIR/lib/adafruit_debouncer.mpy lib/
cp -r $CPBUNDLEDIR/lib/adafruit_ticks.mpy lib/
cp -r $CPBUNDLEDIR/lib/asyncio lib/
cp -r $SCRIPTDIR/boot.py .
cp -r $SCRIPTDIR/duckyinpython.py .
cp -r $SCRIPTDIR/code.py .
mkdir -p payloads
# cp $SCRIPTDIR/.payload.dd payloads/payload.dd
echo -e "\tDone\n"

echo -e "Installing azerty keyboard layout support..."
CPLAYOUTDIR=$CACHEDIR/circuitpython-keyboard-layouts-py-20231122/
cp -r $CPLAYOUTDIR/lib/keyboard_layout_win_fr.py lib/
cp -r $CPLAYOUTDIR/lib/keycode_mac_fr.py lib/
cp -r $CPLAYOUTDIR/lib/keyboard_layout_mac_fr.py lib/
cp -r $CPLAYOUTDIR/lib/keycode_win_fr.py lib/
echo -e "\tDone"

printf "\nThe device is now ready, and you may install your payload.dd in ${MOUNT_PATH}\n"
