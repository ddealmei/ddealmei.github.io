#!/usr/bin/env bash

# Script for installing pico-ducky on a Raspberry Pi Pico 2

CIRCUITPYTHON_BUNDLE_VERSION="9.x"
CIRCUITPYTHON_BUNDLE_FILE="adafruit-circuitpython-bundle-9.x-mpy-20250319.zip"
CIRCUITPYTHON_VERSION="9.2.5"
CIRCUITPYTHON_LANG="fr"
CIRCUITPYTHON_FILE="adafruit-circuitpython-raspberry_pi_pico2-${CIRCUITPYTHON_LANG}-${CIRCUITPYTHON_VERSION}.uf2"

MEDIA_PATH="/media"
PI_NAME="RP2350" # "RPI-RP2" for pico 1

waitForFile() {
    FILETOWAITFOR=$1
    set +e
    while true
    do
        ls $FILETOWAITFOR &> /dev/null
        if [ "$?" -eq 0 ]
        then
            break
        fi
        echo -e "\tWaiting for $FILETOWAITFOR to appear..."
        read -p "Press [Enter] to retry or provide the correct path: " USER_INPUT
        if [ -n "$USER_INPUT" ]; then
            FILETOWAITFOR="$USER_INPUT"
        fi
        sleep 2
    done
    set -e
}

set -e
SCRIPTDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null && pwd )"
CACHEDIR=/tmp/pico-ducky-cache
mkdir -p $CACHEDIR
cd $CACHEDIR
echo -e "\tDownloading CircuitPython $CIRCUITPYTHON_VERSION"
set +e;
ls ${CIRCUITPYTHON_FILE} &> /dev/null
CACHED=$?
set -e
if [ "$CACHED" -eq 0 ]
then
    echo -e "\tUsing cached ${CIRCUITPYTHON_FILE}"
else
    wget -q -nv  https://downloads.circuitpython.org/bin/raspberry_pi_pico2/${CIRCUITPYTHON_LANG}/${CIRCUITPYTHON_FILE}
fi

echo -e "\tDownloading CircuitPython bundle $CIRCUITPYTHON_BUNDLE_VERSION"
cd $CACHEDIR
set +e
ls $CIRCUITPYTHON_BUNDLE_FILE &> /dev/null
CACHED=$?
set -e
if [ "$CACHED" -eq 0 ]
then
    echo -e "\tUsing cached $CIRCUITPYTHON_BUNDLE_FILE"
else
    wget -q -nv https://github.com/adafruit/Adafruit_CircuitPython_Bundle/releases/download/20250319/$CIRCUITPYTHON_BUNDLE_FILE
fi

echo -e "\tDownloading flash_nuke.uf2"
set +e
ls flash_nuke.uf2 &> /dev/null
CACHED=$?
set -e
if [ "$CACHED" -eq 0 ]
then
    echo -e "\tUsing cached flash_nuke.uf2"
else
    wget -nv https://datasheets.raspberrypi.com/soft/flash_nuke.uf2
fi

echo -e "\tDownloading additional keyboard layouts"
cd $CACHEDIR
set +e
ls circuitpython-keyboard-layouts-py-20231122.zip &> /dev/null
CACHED=$?
set -e
if [ "$CACHED" -eq 0 ]
then
    echo -e "\tUsing cached circuitpython-keyboard-layouts-py-20231122.zip"
else
    wget -nv https://github.com/Neradoc/Circuitpython_Keyboard_Layouts/releases/download/20231122/circuitpython-keyboard-layouts-py-20231122.zip
fi
unzip -q -o "*.zip"

echo -e "
################################################################################
#                                  Important                                   #
################################################################################
Hold the button on the Pico 2 and plug it in so it shows up as mass storage device "${PI_NAME}"\n"
waitForFile "${MEDIA_PATH}/*/${PI_NAME}"

echo -en "Installing flash_nuke... "
cd ${MEDIA_PATH}/*/${PI_NAME}
cp $CACHEDIR/flash_nuke.uf2 .
echo -e "\n\tDone!"

echo -e "Waiting for the Pico to reboot..."
sleep 3
waitForFile "${MEDIA_PATH}/*/${PI_NAME}"

echo -en "Installing CircuitPython image... "
cd ${MEDIA_PATH}/*/${PI_NAME}
cp $CACHEDIR/$CIRCUITPYTHON_FILE .
echo "\n\tDone!"

echo -e "Waiting for the Pico 2 to reboot again..."
waitForFile "${MEDIA_PATH}/*/CIRCUITPY"

echo -e "Installing pico-ducky and friends..."
cd ${MEDIA_PATH}/*/CIRCUITPY
CPYDIR=`pwd`
CPBUNDLEDIR=$CACHEDIR/${CIRCUITPYTHON_BUNDLE_FILE/.zip}/
cp -r $CPBUNDLEDIR/lib/adafruit_hid lib/
cp -r $CPBUNDLEDIR/lib/adafruit_debouncer.mpy lib/
cp -r $CPBUNDLEDIR/lib/adafruit_ticks.mpy lib/
cp -r $CPBUNDLEDIR/lib/asyncio lib/
cp -r $SCRIPTDIR/boot.py .
cp -r $SCRIPTDIR/duckyinpython.py .
cp -r $SCRIPTDIR/code.py .
mkdir -p payloads
# cp $SCRIPTDIR/.payload.dd payloads/payload.dd
echo -e "\n\tDone"

echo -e "Installing azerty keyboard layout support..."
cd ${MEDIA_PATH}/*/CIRCUITPY
CPYDIR=`pwd`
CPLAYOUTDIR=$CACHEDIR/circuitpython-keyboard-layouts-py-20231122/
cp -r $CPLAYOUTDIR/lib/keyboard_layout_win_fr.py lib/
cp -r $CPLAYOUTDIR/lib/keycode_mac_fr.py lib/
cp -r $CPLAYOUTDIR/lib/keyboard_layout_mac_fr.py lib/
cp -r $CPLAYOUTDIR/lib/keycode_win_fr.py lib/
echo -e "\n\tDone"

printf "\nThe device is now ready, and you may install your payload.dd in $CPYDIR\n"
