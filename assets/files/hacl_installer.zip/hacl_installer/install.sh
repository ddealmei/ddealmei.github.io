#!/bin/sh

set -e 

unzip haclstar.zip
cd haclstar/gcc-compatible && ./configure
cd ../..
make -C ./haclstar/gcc-compatible CC=clang -j libevercrypt.so
ln -s $(pwd)/haclstar/kremlin/include/kremlin $(pwd)/haclstar/gcc-compatible/kremlin
