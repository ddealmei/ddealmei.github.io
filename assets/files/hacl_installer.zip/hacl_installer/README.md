# HaCl* installer

Simple installer to deploy the fixed version of HaCl* library on the system.

It compiles the library properly.

Then, you need to define the following environment variable to link to your
local installation. Let HACL_PATH be the path to this directory
```
export C_INCLUDE_PATH=$C_INCLUDE_PATH:$HACL_PATH/haclstar/gcc-compatible:$HACL_PATH/haclstar/gcc-compatible/kremlin:$HACL_PATH/haclstar/kremlin/kremlib/dist/minimal
export LIBRARY_PATH=$LIBRARY_PATH:$HACL_PATH/haclstar/gcc-compatible
```

## Requirements

The installation process requires both `make` and `clang`.